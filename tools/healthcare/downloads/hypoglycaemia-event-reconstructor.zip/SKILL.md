---
name: hypoglycaemia-event-reconstructor
description: Reconstructs a de-identified suspected hypoglycaemia event from glucose, medication, meal, activity, symptom, and treatment timestamps; separates observed facts from plausible contributors and missing evidence. Use for safety review, incident discussion, or prevention planning without asserting causality.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Hypoglycaemia Event Reconstructor

## Workflow

1. Normalize all event timestamps and time zones.
2. Build a minute-by-minute sequence of glucose values, medicines, meals,
   activity, symptoms, treatment, and recovery.
3. Classify evidence as observed, reported, inferred, or missing.
4. List plausible contributors with supporting and contradicting evidence.
5. Flag severity indicators and whether confirmation or assistance was recorded.
6. Produce focused questions for clinician and patient review.

## Safety boundaries

- Do not assert a root cause or blame a patient or clinician.
- Do not recommend a dose or regimen change.
- If the event may be ongoing, instruct the user to follow their established
  emergency plan and seek direct medical help rather than continue analysis.
- Distinguish sensor readings from capillary or laboratory confirmation.

Use `assets/sample-event.json` for the bundled demonstration.


---
name: cgm-safety-copilot
description: Converts de-identified continuous glucose monitor exports and event notes into a guarded clinician brief with standard CGM metrics, time-of-day patterns, data-quality checks, hypotheses, and questions for review. Use for retrospective CGM pattern review, AGP preparation, or a diabetes consultation; never use it to prescribe or autonomously change insulin.
license: Apache-2.0
compatibility: Designed for ChatGPT Skills; requires spreadsheet or file analysis for uploaded CGM exports.
metadata:
  author: neurabrix
  version: "1.0.0"
---

# CGM Safety Copilot

## Workflow

1. Confirm the input is fictional or de-identified. Stop if direct identifiers
   appear.
2. State the observation period, sensor coverage, units, target range supplied,
   and material data gaps.
3. Calculate or extract time in range, time below range, time above range,
   mean glucose, variability, and notable day/night patterns. Do not invent a
   metric that cannot be calculated.
4. Separate the output into:
   - observed data;
   - plausible contributors to discuss;
   - missing context;
   - urgent review flags;
   - consultation questions.
5. Use neutral language such as “pattern compatible with” and “consider
   reviewing.” Do not assert causation.
6. End with a compact clinician verification checklist.

## Safety boundaries

- Do not recommend dose changes, pump setting changes, or treatment initiation.
- Do not call an isolated sensor value a diagnosis or emergency without
  clinical correlation.
- Flag prolonged or repeated low readings for prompt clinician review and state
  that symptoms and capillary confirmation may matter.
- If pregnancy, acute illness, recurrent severe hypoglycaemia, or impaired
  awareness appears, elevate the need for direct clinical review.

## Output

Return:

1. **30-second summary**
2. **Metrics and data quality**
3. **Pattern clock** by overnight, morning, afternoon, and evening
4. **Observed vs inferred** audit table
5. **Questions for the consultation**
6. **Clinician must verify**

Use `assets/sample-cgm.csv` for the bundled demonstration.


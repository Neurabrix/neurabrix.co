---
name: medical-myth-evidence-checker
description: Converts a patient-facing health claim into a respectful evidence-checking workflow that defines the claim, distinguishes what is known from uncertain, identifies harms of acting on it, and drafts a plain-language response with sources. Use for diabetes, thyroid, obesity, diet, supplement, and hormone myths.
license: Apache-2.0
compatibility: Web search is recommended for current evidence and source links.
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Medical Myth Evidence Checker

## Workflow

1. Restate the claim neutrally and identify what decision it could influence.
2. Search current primary guidance or high-quality systematic evidence when web
   access is available. Show publication date and source type.
3. Classify the claim as supported, partly supported, unsupported, misleading,
   or not currently answerable.
4. Explain what is true, what is missing, and the possible harm of acting on
   the claim.
5. Draft a non-confrontational patient response in plain language.
6. Provide source links and a clinician verification section.

## Safety boundaries

- Do not fabricate citations or rely on an uncited statistic.
- Do not shame cultural beliefs or promise certainty.
- Do not advise stopping prescribed treatment.
- Mark outdated, indirect, animal, or low-quality evidence clearly.

Use `assets/sample-claim.txt` for the bundled demonstration.


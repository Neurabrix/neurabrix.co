---
name: medicine-constituent-navigator
description: Extracts active ingredients and strengths from medicine labels or supplied catalogues, groups equivalent constituents, flags duplicate exposure, and prepares a pharmacy availability query. Use for Indian brand-name reconciliation or generic substitution discussions; never infer live stock without a connected source.
license: Apache-2.0
compatibility: Live pharmacy availability requires an approved external API or app; otherwise use only supplied catalogue data.
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Medicine Constituent Navigator

## Workflow

1. Extract each exact product name, active ingredient, strength, formulation,
   and schedule only from the supplied label or catalogue.
2. Normalize ingredient names while preserving the original label text.
3. Flag exact duplicates, same-ingredient different-strength products,
   combination overlap, and uncertain matches.
4. Separate “ingredient match” from “clinically interchangeable.”
5. If a connected pharmacy source exists, query location and timestamp and
   label the result as availability reported by that source. Otherwise prepare
   a search list and state that stock is unknown.

## Safety boundaries

- Do not tell the patient to substitute, start, stop, or change a medicine.
- Do not infer bioequivalence, release formulation equivalence, or stock.
- Escalate ambiguous labels, look-alike names, and dose duplication for pharmacist
  or prescriber verification.

Use `assets/sample-medicines.json` for the bundled demonstration. Product names
in the sample are fictional.


---
name: guideline-visit-checklist
description: Converts a supplied guideline excerpt and de-identified case into a consultation checklist that maps each recommendation to case evidence, missing information, and a patient-facing plan. Use when a clinician needs source-grounded preparation without relying on model memory.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Guideline Visit Checklist

## Workflow

1. Treat only the supplied excerpt as authoritative for the task.
2. Extract each recommendation, population, exceptions, strength or certainty
   wording, and source date.
3. Map each recommendation to present, absent, conflicting, or missing case
   evidence.
4. Create a consultation checklist with source quotes kept short and clearly
   attributed.
5. Draft a patient plan that contains questions and agreed-next-step placeholders,
   not autonomous decisions.

## Safety boundaries

- Never invent a recommendation or citation.
- Do not treat a guideline as a mandate for an individual patient.
- Flag that local formulary, comorbidity, pregnancy, contraindications, and
  patient preferences may alter application.
- State when the excerpt is incomplete or old.

Use `assets/sample-guideline-case.json` for the bundled demonstration. The
guideline text is fictional and exists only to demonstrate grounded workflow.


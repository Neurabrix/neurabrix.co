---
name: indian-diet-plan-generator
description: Drafts an illustrative Indian meal plan for a clinician-supplied calorie target, region, dietary pattern, preferences, allergies, budget, cooking access, and restrictions. Use for structured diet counselling drafts in diabetes, obesity, PCOS, fatty liver, or dyslipidaemia care.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Indian Diet Plan Generator

## Workflow

1. Confirm the calorie target is clinician-supplied and list dietary pattern,
   region, allergies, restrictions, meal timing, budget, and cooking access.
2. Allocate approximate calories across meals and show the arithmetic.
3. Build a one-day plan using household measures and locally familiar foods.
4. Give two equivalent swaps per meal and a shopping/preparation note.
5. Flag nutrition assumptions and missing renal, pregnancy, eating-disorder, or
   food-security context.

## Safety boundaries

- Do not calculate or prescribe a therapeutic calorie target from patient data.
- Do not create renal, pregnancy, paediatric, eating-disorder, or post-bariatric
  plans without specialist oversight.
- Treat calories and portions as estimates, not exact prescriptions.
- Avoid moral language such as “good” and “bad” foods.

Use `assets/sample-request.json` for the bundled demonstration.


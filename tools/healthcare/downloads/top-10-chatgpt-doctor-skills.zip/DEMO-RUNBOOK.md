# Demo runbook

## How to run

### ChatGPT Skills

Upload one ZIP from `dist/` in ChatGPT Skills, install it, start a new chat, and
paste the matching sample input from that skill's `assets/` folder.

### Any regular ChatGPT chat

Paste the universal starter below, followed by the matching sample input.

```text
You are demonstrating a clinician workflow skill with entirely fictional data.
Do not diagnose, prescribe, recommend a dose change, or treat the output as a
medical record. Separate supplied facts from interpretations and missing
information. State the intended clinician use, list urgent red flags first,
show the reasoning in a concise audit table, and end with a "Clinician must
verify" section. If the input contains direct identifiers, stop and ask for a
de-identified version.

Apply the workflow named in the first line of the sample input. Return a
presentation-ready result that can be read in under one minute.
```

## Suggested live sequence

1. Open the Skill Lab.
2. Run **CGM Safety Copilot** to establish the clinical wow moment.
3. Run **Medicine Constituent Navigator** to show a hidden duplicate ingredient.
4. Run **Multilingual Patient Explainer** to show an Indian-language output.
5. Run **Medical Myth Evidence Checker** to show safety and evidence discipline.
6. End on the all-ten library view and state that the same pattern works with or
   without an installed skill.

## Safety line to say aloud

“A skill does not make ChatGPT a doctor. It makes the workflow repeatable:
de-identify first, structure the analysis, expose uncertainty, and require a
clinician to verify the result.”


---
name: endocrine-case-timeline
description: Reconstructs a de-identified endocrine record into a dated longitudinal timeline that aligns symptoms, medicines, laboratory results, imaging, interventions, and response. Use for complex endocrine referrals, case conferences, or pre-visit chart review when chronology is fragmented.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Endocrine Case Timeline

## Workflow

1. Stop if the record contains direct identifiers.
2. Normalize dates without changing their precision. Mark an approximate or
   missing date as such.
3. Create one row per event with date, domain, fact, source, and confidence.
4. Link medication or intervention changes to subsequent laboratory and symptom
   trends only as temporal associations.
5. Surface contradictions, duplicated tests, unit changes, and missing
   intervals.
6. Produce a one-paragraph problem representation and five questions that the
   chronology makes important.

## Safety boundaries

- Never convert temporal association into causation.
- Preserve original units and reference ranges where supplied.
- Never infer a diagnosis that is absent from the record.
- Label model-created summaries as draft clinical support.

## Output

Return a chronological table, trend summary, contradictions, missing evidence,
consultation questions, and clinician verification section.

Use `assets/sample-case.json` for the bundled demonstration.


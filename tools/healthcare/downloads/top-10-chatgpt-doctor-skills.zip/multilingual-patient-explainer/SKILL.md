---
name: multilingual-patient-explainer
description: Drafts plain-language, culturally appropriate patient education for a specified condition, literacy level, language, and delivery channel, with teach-back questions and clinician review cues. Use for Indian-language explanations, discharge notes, WhatsApp messages, or visual instruction scripts.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Multilingual Patient Explainer

## Workflow

1. Confirm condition, language, literacy level, audience, channel, and desired
   length.
2. Explain: what it is, why it matters, what the patient can do today, danger
   signs, and next follow-up.
3. Use short sentences and familiar words. Preserve medical terms in English in
   parentheses when that improves recognition.
4. Add three teach-back questions.
5. Return both the target-language version and a clinician-facing English
   back-translation.

## Safety boundaries

- Never invent an individual treatment plan.
- Do not translate a dosage, taper, or emergency instruction unless the
  clinician supplied it verbatim.
- Flag language variants that may be ambiguous or locally unfamiliar.
- Require clinician or qualified-language review before patient distribution.

Use `assets/sample-request.json` for the bundled demonstration.


---
name: diabetes-visit-brief
description: Turns a de-identified diabetes chart into a one-minute pre-visit brief with current status, trend changes, safety flags, overdue care gaps, medication reconciliation questions, and an agenda. Use immediately before an outpatient diabetes review.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Diabetes Visit Brief

## Workflow

1. Confirm the chart is fictional or de-identified and state the date range.
2. Summarize diabetes type and duration as recorded, recent HbA1c trend,
   glucose pattern, kidney status, blood pressure, lipids, complications,
   medicines, adherence notes, and recent acute events.
3. Rank care gaps by potential harm and time sensitivity.
4. Separate recorded facts, calculated trends, and questions.
5. Create a three-item visit agenda that the clinician can change.

## Safety boundaries

- Do not diagnose a complication or recommend a medicine or dose change.
- Do not mark a care gap unless the supplied record supports it.
- Use dates, units, and source labels.
- Elevate severe hypoglycaemia, ketosis symptoms, pregnancy, or acute illness.

Use `assets/sample-chart.json` for the bundled demonstration.


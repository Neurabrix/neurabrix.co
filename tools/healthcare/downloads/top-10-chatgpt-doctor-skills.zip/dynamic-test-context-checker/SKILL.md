---
name: dynamic-test-context-checker
description: Checks whether an endocrine dynamic test is interpretable by aligning protocol steps, sample timing, assay units, medicines, preparation, acute illness, and reference criteria. Use before interpreting stimulation or suppression tests and when a test result conflicts with the clinical picture.
license: Apache-2.0
metadata:
  author: neurabrix
  version: "1.0.0"
---

# Dynamic Test Context Checker

## Workflow

1. Identify the test claimed, clinical question, stated protocol, sampling
   times, units, assay information, and interpretation criterion supplied.
2. Compare the actual sequence with the supplied protocol. Do not import a
   cutoff from memory as authoritative.
3. List preparation factors: fasting, time of day, acute illness, medicines,
   exogenous hormones, and sample handling.
4. Classify each issue as: interpretable, potentially confounded, protocol
   deviation, or insufficient information.
5. End with the exact missing facts needed before a clinician interprets the
   result.

## Safety boundaries

- Do not diagnose adrenal, pituitary, or other endocrine disease.
- Do not recommend starting or stopping medicines.
- Do not mix assay-specific thresholds or units.
- Treat the supplied institutional protocol as the source for this workflow.

Use `assets/sample-test.json` for the bundled demonstration.


# Top 10 ChatGPT Skills for Doctors

Ten portable, synthetic-data-first clinical workflow skills for a live demonstration.

Each skill folder follows the Agent Skills open standard and can be uploaded to
ChatGPT as a ZIP. The same sample can also be pasted into an ordinary ChatGPT
conversation using the universal prompt in `DEMO-RUNBOOK.md`.

These skills support clinician workflow and communication. They do not diagnose,
prescribe, replace clinical judgment, or authorize treatment changes.

## Skills

1. `cgm-safety-copilot`
2. `endocrine-case-timeline`
3. `dynamic-test-context-checker`
4. `medical-myth-evidence-checker`
5. `multilingual-patient-explainer`
6. `indian-diet-plan-generator`
7. `medicine-constituent-navigator`
8. `diabetes-visit-brief`
9. `guideline-visit-checklist`
10. `hypoglycaemia-event-reconstructor`

## Presentation rule

Use only the bundled fictional cases. Never paste names, phone numbers,
addresses, hospital numbers, exact dates of birth, or other direct identifiers.

